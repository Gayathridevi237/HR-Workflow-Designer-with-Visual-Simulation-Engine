# HR Workflow Designer

A prototype HR Workflow Designer built with **React + TypeScript + Vite**, **React Flow (@xyflow/react)**, **Zustand**, and **Tailwind CSS**. Submitted as the Tredence Studio Full Stack Engineering Intern case study.

## Features

- **Drag-and-drop canvas** with five custom node types: Start, Task, Approval, Automated, End
- **Dynamic Properties Panel** — node-type-aware forms (controlled inputs, type-safe via discriminated unions)
- **Mock API layer** — `fetchAutomationActions` (GET /automations) and `simulateWorkflow` (POST /simulate)
- **Sandbox panel** — BFS traversal of the graph with step-by-step execution log
- **Validation** — missing Start, missing connections, missing assignees/actions, cycle detection. Errors are surfaced inline on nodes (red outline + badge) and listed in the sandbox.
- **Bonus**:
  - Export / Import workflow as JSON
  - Undo / Redo (50-step history)
  - Auto-approve threshold (Approval node)
  - Dynamic action parameters (Automated node, derived from mock API definition)
  - MiniMap, zoom controls
  - Reset workflow

## Run

```bash
npm install
npm run dev
```

## Architecture

```
src/features/workflow/
├── components/
│   ├── Canvas.tsx          # React Flow canvas + drop handlers
│   ├── Sidebar.tsx         # Draggable node palette
│   ├── WorkflowNode.tsx    # Single custom node renderer (all kinds)
│   ├── PropertiesPanel.tsx # Dynamic edit form, dispatched on node.kind
│   ├── SandboxPanel.tsx    # Simulation runner + validation surface
│   └── Toolbar.tsx         # Undo/Redo/Import/Export/Reset
├── store.ts                # Zustand store (graph state + history)
├── types.ts                # Discriminated-union node types
├── validation.ts           # Pure graph validation (cycles, completeness)
└── mockApi.ts              # GET /automations + POST /simulate (in-memory)
```

### Design decisions

- **Single custom node component** (`workflow`) that branches on `data.kind` instead of one component per kind. Keeps React Flow registration simple while remaining fully type-safe via the discriminated union in `types.ts`.
- **Zustand** chosen over Context for ergonomic selectors and to keep React Flow change handlers (`onNodesChange`, `onEdgesChange`, `onConnect`) colocated with state.
- **History** is implemented as snapshot stacks (`past` / `future`). Snapshots are pushed on structural mutations (add/remove/connect/import/reset) — not on every drag tick, to keep undo meaningful.
- **Validation** is a pure function over `(nodes, edges)` so it can be reused by both the sandbox panel and the per-node badge in `WorkflowNode`.
- **Mock API** lives in a single module with `setTimeout`-based async to model real network latency without adding MSW or json-server overhead for a 4–6h timebox.

### Extending with a new node kind

1. Add the kind to `NodeKind` and a corresponding interface in `types.ts`
2. Add a default value in `defaultDataFor`
3. Add a `<KindFields>` component in `PropertiesPanel.tsx`
4. (Optional) handle it in `WorkflowNode.tsx` body and `mockApi.ts` `describe`/`completion`

The discriminated union ensures the TypeScript compiler flags every place that needs an update.

## What I would add with more time

- Replace mock API with MSW so requests show up in DevTools Network tab
- Real-time multi-user editing via Yjs / WebSockets
- Auto-layout (dagre) and node templates
- Per-node validation panel inside the Properties drawer
- Storybook for the node + form components
- Unit tests (Vitest) for `validation.ts` and `mockApi.simulateWorkflow`
- E2E tests (Playwright) for the drag/drop + simulate flow