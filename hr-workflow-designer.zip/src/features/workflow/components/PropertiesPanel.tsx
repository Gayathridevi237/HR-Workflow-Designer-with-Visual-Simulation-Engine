import { useEffect, useState } from "react";
import { Trash2, Settings2, Play, CheckSquare, ShieldCheck, Zap, Flag, type LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useWorkflowStore } from "../store";
import { fetchAutomationActions, type AutomationAction } from "../mockApi";
import type {
  ApprovalNodeData,
  AutomatedNodeData,
  EndNodeData,
  NodeKind,
  StartNodeData,
  TaskNodeData,
} from "../types";
import { NODE_LABELS } from "../types";

const ICONS: Record<NodeKind, LucideIcon> = {
  start: Play,
  task: CheckSquare,
  approval: ShieldCheck,
  automated: Zap,
  end: Flag,
};

const ACCENTS: Record<NodeKind, string> = {
  start: "bg-emerald-500",
  task: "bg-blue-500",
  approval: "bg-amber-500",
  automated: "bg-violet-500",
  end: "bg-rose-500",
};

export function PropertiesPanel() {
  const selectedId = useWorkflowStore((s) => s.selectedNodeId);
  const node = useWorkflowStore((s) => s.nodes.find((n) => n.id === selectedId));
  const update = useWorkflowStore((s) => s.updateNodeData);
  const remove = useWorkflowStore((s) => s.removeNode);

  if (!node) {
    return (
      <aside className="w-80 border-l border-border bg-card flex flex-col">
        <div className="px-4 py-4 border-b border-border">
          <h2 className="text-sm font-semibold text-foreground">Properties</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Configure your nodes</p>
        </div>
        <div className="flex-1 flex items-center justify-center p-8 text-center">
          <div className="flex flex-col items-center gap-3 text-muted-foreground">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
              <Settings2 className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">No node selected</p>
              <p className="text-xs mt-1">Click a node on the canvas to edit its properties.</p>
            </div>
          </div>
        </div>
      </aside>
    );
  }

  const data = node.data;
  const Icon = ICONS[data.kind];

  return (
    <aside className="w-80 border-l border-border bg-card flex flex-col">
      <div className="px-4 py-4 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className={`flex h-8 w-8 items-center justify-center rounded-md ${ACCENTS[data.kind]} text-white shadow-sm`}>
            <Icon className="h-4 w-4" strokeWidth={2.5} />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-foreground">{NODE_LABELS[data.kind]}</h2>
            <p className="text-[11px] text-muted-foreground">Node configuration</p>
          </div>
        </div>
        {data.kind !== "start" && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => remove(node.id)}
            className="h-8 w-8 p-0 text-destructive hover:text-destructive hover:bg-destructive/10"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
        <Field label="Title">
          <input
            className="input"
            value={data.title}
            onChange={(e) => update(node.id, { title: e.target.value })}
          />
        </Field>

        {data.kind === "start" && <StartFields data={data} id={node.id} />}
        {data.kind === "task" && <TaskFields data={data} id={node.id} />}
        {data.kind === "approval" && <ApprovalFields data={data} id={node.id} />}
        {data.kind === "automated" && <AutomatedFields data={data} id={node.id} />}
        {data.kind === "end" && <EndFields data={data} id={node.id} />}
      </div>
    </aside>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-xs font-medium text-foreground">{label}</span>
      {children}
    </label>
  );
}

function StartFields({ data, id }: { data: StartNodeData; id: string }) {
  const update = useWorkflowStore((s) => s.updateNodeData);
  return (
    <Field label="Metadata">
      <textarea
        className="input"
        rows={3}
        value={data.metadata}
        onChange={(e) => update(id, { metadata: e.target.value })}
      />
    </Field>
  );
}

function TaskFields({ data, id }: { data: TaskNodeData; id: string }) {
  const update = useWorkflowStore((s) => s.updateNodeData);
  return (
    <>
      <Field label="Description">
        <textarea
          className="input"
          rows={2}
          value={data.description}
          onChange={(e) => update(id, { description: e.target.value })}
        />
      </Field>
      <Field label="Assignee">
        <input
          className="input"
          value={data.assignee}
          onChange={(e) => update(id, { assignee: e.target.value })}
        />
      </Field>
      <Field label="Due Date">
        <input
          type="date"
          className="input"
          value={data.dueDate}
          onChange={(e) => update(id, { dueDate: e.target.value })}
        />
      </Field>
    </>
  );
}

function ApprovalFields({ data, id }: { data: ApprovalNodeData; id: string }) {
  const update = useWorkflowStore((s) => s.updateNodeData);
  return (
    <>
    <Field label="Approver Role">
      <select
        className="input"
        value={data.approverRole}
        onChange={(e) => update(id, { approverRole: e.target.value })}
      >
        <option>Manager</option>
        <option>HR</option>
          <option>HRBP</option>
        <option>Director</option>
        <option>CEO</option>
      </select>
    </Field>
      <Field label="Auto-approve threshold">
        <input
          type="number"
          className="input"
          value={data.autoApproveThreshold}
          onChange={(e) =>
            update(id, { autoApproveThreshold: Number(e.target.value) || 0 })
          }
        />
      </Field>
    </>
  );
}

function AutomatedFields({ data, id }: { data: AutomatedNodeData; id: string }) {
  const update = useWorkflowStore((s) => s.updateNodeData);
  const [actions, setActions] = useState<AutomationAction[]>([]);
  useEffect(() => {
    fetchAutomationActions().then(setActions);
  }, []);
  const selected = actions.find((a) => a.id === data.actionId);
  return (
    <>
    <Field label="Action">
      <select
        className="input"
        value={data.actionId}
          onChange={(e) => update(id, { actionId: e.target.value, actionParams: {} })}
      >
        <option value="">Select an action…</option>
        {actions.map((a) => (
          <option key={a.id} value={a.id}>
            {a.label}
          </option>
        ))}
      </select>
    </Field>
      {selected && selected.params.length > 0 && (
        <div className="flex flex-col gap-3 rounded-lg border border-border bg-muted/40 p-3">
          <span className="text-xs font-semibold text-foreground">Action Parameters</span>
          {selected.params.map((p) => (
            <Field key={p} label={p}>
              <input
                className="input"
                value={data.actionParams[p] ?? ""}
                onChange={(e) =>
                  update(id, {
                    actionParams: { ...data.actionParams, [p]: e.target.value },
                  })
                }
              />
            </Field>
          ))}
        </div>
      )}
    </>
  );
}

function EndFields({ data, id }: { data: EndNodeData; id: string }) {
  const update = useWorkflowStore((s) => s.updateNodeData);
  return (
    <>
      <Field label="Message">
        <textarea
          className="input"
          rows={2}
          value={data.message}
          onChange={(e) => update(id, { message: e.target.value })}
        />
      </Field>
      <div className="flex items-center justify-between rounded-lg border border-border bg-muted/40 px-3 py-2.5">
        <div>
          <div className="text-sm font-medium text-foreground">Show summary</div>
          <div className="text-[11px] text-muted-foreground">Display recap when workflow completes</div>
        </div>
        <Switch
          checked={data.showSummary}
          onCheckedChange={(v) => update(id, { showSummary: v })}
        />
      </div>
    </>
  );
}