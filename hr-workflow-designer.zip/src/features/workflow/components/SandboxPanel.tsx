import { useState } from "react";
import { Play, Trash2, AlertCircle, AlertTriangle, CheckCircle2, Loader2, FlaskConical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useWorkflowStore } from "../store";
import { simulateWorkflow, type SimulationStep } from "../mockApi";
import { validateWorkflow } from "../validation";

export function SandboxPanel() {
  const nodes = useWorkflowStore((s) => s.nodes);
  const edges = useWorkflowStore((s) => s.edges);
  const [steps, setSteps] = useState<SimulationStep[]>([]);
  const [running, setRunning] = useState(false);
  const issues = validateWorkflow(nodes, edges);
  const errors = issues.filter((i) => i.severity === "error");

  const run = async () => {
    if (errors.length > 0) return;
    setSteps([]);
    setRunning(true);
    await simulateWorkflow(nodes, edges, (step) => {
      setSteps((prev) => {
        if (step.status === "done") {
          return prev.map((s) =>
            s.nodeId === step.nodeId && s.status === "running" ? step : s,
          );
        }
        return [...prev, step];
      });
    });
    setRunning(false);
  };

  return (
    <div className="h-56 border-t border-border bg-card overflow-hidden flex flex-col">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-border bg-muted/30">
        <div className="flex items-center gap-2.5">
          <div className="flex h-7 w-7 items-center justify-center rounded-md bg-gradient-to-br from-primary to-primary/70 text-primary-foreground shadow-sm">
            <FlaskConical className="h-3.5 w-3.5" strokeWidth={2.5} />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-foreground leading-tight">Sandbox</h2>
            <p className="text-[11px] text-muted-foreground leading-tight">Simulate workflow execution</p>
          </div>
          {issues.length > 0 && (
            <span
              className={`ml-2 inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full font-medium ${
                errors.length > 0
                  ? "bg-destructive/15 text-destructive"
                  : "bg-amber-500/15 text-amber-600"
              }`}
            >
              {errors.length > 0 ? (
                <AlertCircle className="h-3 w-3" />
              ) : (
                <AlertTriangle className="h-3 w-3" />
              )}
              {errors.length > 0
                ? `${errors.length} error${errors.length > 1 ? "s" : ""}`
                : `${issues.length} warning${issues.length > 1 ? "s" : ""}`}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={() => setSteps([])} className="h-8 gap-1.5">
            <Trash2 className="h-3.5 w-3.5" />
            Clear
          </Button>
          <Button
            size="sm"
            onClick={run}
            disabled={running || errors.length > 0}
            className="h-8 gap-1.5 bg-gradient-to-r from-primary to-primary/80 hover:opacity-90 shadow-sm"
          >
            {running ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <Play className="h-3.5 w-3.5 fill-current" />
            )}
            {running ? "Running…" : "Run Simulation"}
          </Button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-3 space-y-1">
        {issues.length > 0 && (
          <div className="mb-3 space-y-1 rounded-lg border border-border bg-muted/30 p-2.5">
            {issues.map((i, idx) => (
              <div
                key={idx}
                className={`flex items-start gap-2 text-xs ${
                  i.severity === "error" ? "text-destructive" : "text-amber-600"
                }`}
              >
                {i.severity === "error" ? (
                  <AlertCircle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
                )}
                <span>{i.message}</span>
              </div>
            ))}
          </div>
        )}
        {steps.length === 0 ? (
          <div className="h-full flex items-center justify-center text-center">
            <div className="text-muted-foreground">
              <p className="text-sm">No simulation run yet</p>
              <p className="text-xs mt-1">Click "Run Simulation" to test your workflow</p>
            </div>
          </div>
        ) : (
          steps.map((s, i) => (
            <div
              key={i}
              className="flex items-center gap-3 rounded-lg border border-border bg-background px-3 py-2 text-sm"
            >
              <div className="shrink-0">
                {s.status === "done" ? (
                  <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                ) : s.status === "running" ? (
                  <Loader2 className="h-4 w-4 text-primary animate-spin" />
                ) : (
                  <div className="h-4 w-4 rounded-full border-2 border-muted-foreground/30" />
                )}
              </div>
              <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground w-20">
                {s.kind}
              </span>
              <span className="font-medium text-foreground">{s.title}</span>
              <span className="text-muted-foreground text-xs flex-1 truncate">— {s.message}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}