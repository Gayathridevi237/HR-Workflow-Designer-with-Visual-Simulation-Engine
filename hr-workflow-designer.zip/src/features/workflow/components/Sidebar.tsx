import { Play, CheckSquare, ShieldCheck, Zap, Flag, GripVertical, type LucideIcon } from "lucide-react";
import { NODE_LABELS, type NodeKind } from "../types";

const KINDS: NodeKind[] = ["start", "task", "approval", "automated", "end"];

const ICONS: Record<NodeKind, LucideIcon> = {
  start: Play,
  task: CheckSquare,
  approval: ShieldCheck,
  automated: Zap,
  end: Flag,
};

const ACCENTS: Record<NodeKind, string> = {
  start: "bg-emerald-500",
  task: "bg-blue-500",
  approval: "bg-amber-500",
  automated: "bg-violet-500",
  end: "bg-rose-500",
};

const DESCRIPTIONS: Record<NodeKind, string> = {
  start: "Workflow entry point",
  task: "Human action step",
  approval: "Requires sign-off",
  automated: "System action",
  end: "Workflow finish",
};

export function Sidebar() {
  const onDragStart = (e: React.DragEvent, kind: NodeKind) => {
    e.dataTransfer.setData("application/x-workflow-node", kind);
    e.dataTransfer.effectAllowed = "move";
  };

  return (
    <aside className="w-64 border-r border-border bg-card flex flex-col">
      <div className="px-4 py-4 border-b border-border">
        <h2 className="text-sm font-semibold text-foreground">Node Library</h2>
        <p className="text-xs text-muted-foreground mt-0.5">
          Drag onto canvas to add
        </p>
      </div>
      <div className="flex flex-col gap-2 p-3 overflow-y-auto">
        {KINDS.map((k) => {
          const Icon = ICONS[k];
          return (
            <div
              key={k}
              draggable
              onDragStart={(e) => onDragStart(e, k)}
              className="group flex items-center gap-3 cursor-grab rounded-lg border border-border bg-background px-3 py-2.5 hover:border-primary/50 hover:shadow-sm hover:bg-accent/40 active:cursor-grabbing transition-all"
            >
              <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-md ${ACCENTS[k]} text-white shadow-sm`}>
                <Icon className="h-4 w-4" strokeWidth={2.5} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-foreground">
                  {NODE_LABELS[k]}
                </div>
                <div className="text-[11px] text-muted-foreground truncate">
                  {DESCRIPTIONS[k]}
                </div>
              </div>
              <GripVertical className="h-4 w-4 text-muted-foreground/40 group-hover:text-muted-foreground transition-colors" />
            </div>
          );
        })}
      </div>
      <div className="mt-auto px-4 py-3 border-t border-border bg-muted/30">
        <p className="text-[11px] text-muted-foreground leading-relaxed">
          💡 Tip: Connect nodes by dragging from the right edge to the left edge of another node.
        </p>
      </div>
    </aside>
  );
}