import { useRef } from "react";
import { Undo2, Redo2, Download, Upload, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useWorkflowStore } from "../store";

export function Toolbar() {
  const exportJson = useWorkflowStore((s) => s.exportJson);
  const importJson = useWorkflowStore((s) => s.importJson);
  const undo = useWorkflowStore((s) => s.undo);
  const redo = useWorkflowStore((s) => s.redo);
  const reset = useWorkflowStore((s) => s.reset);
  const past = useWorkflowStore((s) => s.past.length);
  const future = useWorkflowStore((s) => s.future.length);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleExport = () => {
    const json = exportJson();
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "workflow.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportClick = () => fileRef.current?.click();
  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    importJson(text);
    e.target.value = "";
  };

  return (
    <div className="flex items-center gap-1">
      <Button
        variant="ghost"
        size="sm"
        onClick={undo}
        disabled={past === 0}
        className="h-8 gap-1.5"
      >
        <Undo2 className="h-3.5 w-3.5" />
        <span className="hidden sm:inline">Undo</span>
      </Button>
      <Button
        variant="ghost"
        size="sm"
        onClick={redo}
        disabled={future === 0}
        className="h-8 gap-1.5"
      >
        <Redo2 className="h-3.5 w-3.5" />
        <span className="hidden sm:inline">Redo</span>
      </Button>
      <div className="mx-1 h-5 w-px bg-border" />
      <Button variant="ghost" size="sm" onClick={handleExport} className="h-8 gap-1.5">
        <Download className="h-3.5 w-3.5" />
        <span className="hidden sm:inline">Export</span>
      </Button>
      <Button variant="ghost" size="sm" onClick={handleImportClick} className="h-8 gap-1.5">
        <Upload className="h-3.5 w-3.5" />
        <span className="hidden sm:inline">Import</span>
      </Button>
      <input
        ref={fileRef}
        type="file"
        accept="application/json"
        className="hidden"
        onChange={handleFile}
      />
      <div className="mx-1 h-5 w-px bg-border" />
      <Button variant="ghost" size="sm" onClick={reset} className="h-8 gap-1.5 text-destructive hover:text-destructive">
        <RotateCcw className="h-3.5 w-3.5" />
        <span className="hidden sm:inline">Reset</span>
      </Button>
    </div>
  );
}