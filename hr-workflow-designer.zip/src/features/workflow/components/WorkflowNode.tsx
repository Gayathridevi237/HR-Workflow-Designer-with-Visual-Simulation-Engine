import { Handle, Position, type NodeProps } from "@xyflow/react";
import {
  Play,
  CheckSquare,
  ShieldCheck,
  Zap,
  Flag,
  AlertCircle,
  AlertTriangle,
  type LucideIcon,
} from "lucide-react";
import { NODE_ACCENT, NODE_LABELS, type NodeKind, type WorkflowNodeData } from "../types";
import { useWorkflowStore } from "../store";
import { validateWorkflow } from "../validation";

const NODE_ICONS: Record<NodeKind, LucideIcon> = {
  start: Play,
  task: CheckSquare,
  approval: ShieldCheck,
  automated: Zap,
  end: Flag,
};

export function WorkflowNodeView({ id, data, selected }: NodeProps) {
  const d = data as WorkflowNodeData;
  const Icon = NODE_ICONS[d.kind];
  const accent = NODE_ACCENT[d.kind];
  const isStart = d.kind === "start";
  const isEnd = d.kind === "end";
  const nodes = useWorkflowStore((s) => s.nodes);
  const edges = useWorkflowStore((s) => s.edges);
  const issues = validateWorkflow(nodes, edges).filter((i) => i.nodeId === id);
  const hasError = issues.some((i) => i.severity === "error");
  const hasWarning = issues.some((i) => i.severity === "warning");

  return (
    <div
      className={`group relative min-w-[200px] rounded-xl border bg-card backdrop-blur-sm transition-all duration-200 ${
        selected
          ? "border-primary shadow-[0_10px_30px_-10px_oklch(0.55_0.22_265/0.4)] scale-[1.02]"
          : "border-border shadow-[0_2px_8px_oklch(0.2_0.04_260/0.06)] hover:shadow-[0_6px_20px_oklch(0.2_0.04_260/0.1)]"
      } ${hasError ? "ring-2 ring-destructive/60" : ""}`}
      title={issues.map((i) => i.message).join("\n")}
    >
      {!isStart && (
        <Handle
          type="target"
          position={Position.Left}
          className="!w-3 !h-3 !bg-primary !border-2 !border-card"
        />
      )}

      {/* Accent stripe */}
      <div className={`absolute left-0 top-0 bottom-0 w-1 rounded-l-xl ${accent}`} />

      <div className="px-3.5 py-3 pl-4">
        <div className="flex items-center justify-between gap-2 mb-1.5">
          <div className="flex items-center gap-1.5">
            <div className={`flex h-5 w-5 items-center justify-center rounded ${accent} text-white`}>
              <Icon className="h-3 w-3" strokeWidth={2.5} />
            </div>
            <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              {NODE_LABELS[d.kind]}
            </span>
          </div>
          {(hasError || hasWarning) && (
            <span
              className={`flex items-center gap-0.5 text-[10px] px-1.5 py-0.5 rounded-full font-medium ${
                hasError
                  ? "bg-destructive/15 text-destructive"
                  : "bg-amber-500/15 text-amber-600"
              }`}
            >
              {hasError ? (
                <AlertCircle className="h-2.5 w-2.5" />
              ) : (
                <AlertTriangle className="h-2.5 w-2.5" />
              )}
            </span>
          )}
        </div>

        <div className="text-sm font-semibold text-foreground leading-tight">
          {d.title}
        </div>

        {d.kind === "task" && (
          <div className="mt-1.5 flex items-center gap-1 text-xs text-muted-foreground">
            <span className="truncate">👤 {d.assignee || "Unassigned"}</span>
          </div>
        )}
        {d.kind === "approval" && (
          <div className="mt-1.5 text-xs text-muted-foreground">
            🛡 {d.approverRole}
          </div>
        )}
        {d.kind === "automated" && (
          <div className="mt-1.5 text-xs text-muted-foreground truncate">
            ⚡ {d.actionId || "No action set"}
          </div>
        )}
        {d.kind === "end" && d.message && (
          <div className="mt-1.5 text-xs text-muted-foreground truncate">
            {d.message}
          </div>
        )}
      </div>

      {!isEnd && (
        <Handle
          type="source"
          position={Position.Right}
          className="!w-3 !h-3 !bg-primary !border-2 !border-card"
        />
      )}
    </div>
  );
}