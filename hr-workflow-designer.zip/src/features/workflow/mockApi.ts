import type { WorkflowNodeData } from "./types";
import type { Edge, Node } from "@xyflow/react";

export interface AutomationAction {
  id: string;
  label: string;
  description: string;
  params: string[];
}

const ACTIONS: AutomationAction[] = [
  { id: "send_email", label: "Send Email", description: "Sends a notification email", params: ["to", "subject", "body"] },
  { id: "generate_doc", label: "Generate Document", description: "Generates a PDF document", params: ["template", "recipient"] },
  { id: "create_ticket", label: "Create Ticket", description: "Creates a support ticket", params: ["queue", "priority"] },
  { id: "provision_account", label: "Provision Account", description: "Creates user account", params: ["email", "role"] },
  { id: "assign_equipment", label: "Assign Equipment", description: "Assigns laptop & gear", params: ["assetType"] },
  { id: "schedule_meeting", label: "Schedule Meeting", description: "Books a calendar slot", params: ["attendee", "datetime"] },
];

export async function fetchAutomationActions(): Promise<AutomationAction[]> {
  await new Promise((r) => setTimeout(r, 200));
  return ACTIONS;
}

export interface SimulationStep {
  nodeId: string;
  title: string;
  kind: string;
  status: "running" | "done" | "skipped";
  message: string;
  timestamp: number;
}

export async function simulateWorkflow(
  nodes: Node<WorkflowNodeData>[],
  edges: Edge[],
  onStep: (step: SimulationStep) => void,
): Promise<void> {
  const start = nodes.find((n) => n.data.kind === "start");
  if (!start) {
    onStep({
      nodeId: "n/a",
      title: "Validation",
      kind: "system",
      status: "skipped",
      message: "No Start node found.",
      timestamp: Date.now(),
    });
    return;
  }

  const adjacency = new Map<string, string[]>();
  edges.forEach((e) => {
    const list = adjacency.get(e.source) ?? [];
    list.push(e.target);
    adjacency.set(e.source, list);
  });

  const visited = new Set<string>();
  const queue: string[] = [start.id];

  while (queue.length) {
    const id = queue.shift()!;
    if (visited.has(id)) continue;
    visited.add(id);
    const node = nodes.find((n) => n.id === id);
    if (!node) continue;
    const data = node.data;

    onStep({
      nodeId: id,
      title: data.title,
      kind: data.kind,
      status: "running",
      message: describe(data),
      timestamp: Date.now(),
    });
    await new Promise((r) => setTimeout(r, 600));
    onStep({
      nodeId: id,
      title: data.title,
      kind: data.kind,
      status: "done",
      message: completion(data),
      timestamp: Date.now(),
    });

    const next = adjacency.get(id) ?? [];
    next.forEach((n) => queue.push(n));
  }
}

function describe(d: WorkflowNodeData): string {
  switch (d.kind) {
    case "start":
      return `Starting workflow: ${d.metadata || "no metadata"}`;
    case "task":
      return `Assigning task to ${d.assignee || "unassigned"} (due ${d.dueDate || "—"})`;
    case "approval":
      return `Awaiting approval from ${d.approverRole}` +
        (d.autoApproveThreshold > 0
          ? ` (auto-approve ≤ ${d.autoApproveThreshold})`
          : "");
    case "automated":
      return `Running action: ${d.actionId || "none selected"}` +
        (Object.keys(d.actionParams).length
          ? ` with ${JSON.stringify(d.actionParams)}`
          : "");
    case "end":
      return d.message;
  }
}

function completion(d: WorkflowNodeData): string {
  switch (d.kind) {
    case "start":
      return "Workflow initiated.";
    case "task":
      return `Task "${d.title}" completed.`;
    case "approval":
      return `Approved by ${d.approverRole}.`;
    case "automated":
      return `Automation executed.`;
    case "end":
      return d.showSummary ? "Workflow ended. Summary generated." : "Workflow ended.";
  }
}