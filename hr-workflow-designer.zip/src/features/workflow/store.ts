import { create } from "zustand";
import {
  addEdge,
  applyEdgeChanges,
  applyNodeChanges,
  type Connection,
  type Edge,
  type EdgeChange,
  type Node,
  type NodeChange,
} from "@xyflow/react";
import { defaultDataFor, type NodeKind, type WorkflowNodeData } from "./types";

export type WorkflowNode = Node<WorkflowNodeData>;

interface Snapshot {
  nodes: WorkflowNode[];
  edges: Edge[];
}

interface WorkflowState {
  nodes: WorkflowNode[];
  edges: Edge[];
  selectedNodeId: string | null;
  past: Snapshot[];
  future: Snapshot[];
  onNodesChange: (changes: NodeChange[]) => void;
  onEdgesChange: (changes: EdgeChange[]) => void;
  onConnect: (conn: Connection) => void;
  addNode: (kind: NodeKind, position: { x: number; y: number }) => void;
  updateNodeData: (id: string, patch: Partial<WorkflowNodeData>) => void;
  selectNode: (id: string | null) => void;
  removeNode: (id: string) => void;
  undo: () => void;
  redo: () => void;
  exportJson: () => string;
  importJson: (json: string) => void;
  reset: () => void;
}

let counter = 1;
const nextId = () => `n_${Date.now().toString(36)}_${counter++}`;

const initialNodes: WorkflowNode[] = [
  {
    id: "n_start",
    type: "workflow",
    position: { x: 100, y: 200 },
    data: defaultDataFor("start"),
  },
];

export const useWorkflowStore = create<WorkflowState>((set, get) => ({
  nodes: initialNodes,
  edges: [],
  selectedNodeId: null,
  past: [],
  future: [],
  onNodesChange: (changes) =>
    set({ nodes: applyNodeChanges(changes, get().nodes) as WorkflowNode[] }),
  onEdgesChange: (changes) => set({ edges: applyEdgeChanges(changes, get().edges) }),
  onConnect: (conn) => {
    pushHistory(get, set);
    set({ edges: addEdge({ ...conn, animated: true }, get().edges) });
  },
  addNode: (kind, position) => {
    pushHistory(get, set);
    const node: WorkflowNode = {
      id: nextId(),
      type: "workflow",
      position,
      data: defaultDataFor(kind),
    };
    set({ nodes: [...get().nodes, node] });
  },
  updateNodeData: (id, patch) =>
    set({
      nodes: get().nodes.map((n) =>
        n.id === id ? { ...n, data: { ...n.data, ...patch } as WorkflowNodeData } : n,
      ),
    }),
  selectNode: (id) => set({ selectedNodeId: id }),
  removeNode: (id) => {
    pushHistory(get, set);
    set({
      nodes: get().nodes.filter((n) => n.id !== id),
      edges: get().edges.filter((e) => e.source !== id && e.target !== id),
      selectedNodeId: get().selectedNodeId === id ? null : get().selectedNodeId,
    });
  },
  undo: () => {
    const { past, nodes, edges, future } = get();
    if (!past.length) return;
    const prev = past[past.length - 1];
    set({
      past: past.slice(0, -1),
      future: [...future, { nodes, edges }],
      nodes: prev.nodes,
      edges: prev.edges,
    });
  },
  redo: () => {
    const { future, nodes, edges, past } = get();
    if (!future.length) return;
    const next = future[future.length - 1];
    set({
      future: future.slice(0, -1),
      past: [...past, { nodes, edges }],
      nodes: next.nodes,
      edges: next.edges,
    });
  },
  exportJson: () => {
    const { nodes, edges } = get();
    return JSON.stringify({ nodes, edges }, null, 2);
  },
  importJson: (json) => {
    try {
      const parsed = JSON.parse(json);
      if (!Array.isArray(parsed.nodes) || !Array.isArray(parsed.edges)) return;
      pushHistory(get, set);
      set({ nodes: parsed.nodes, edges: parsed.edges, selectedNodeId: null });
    } catch {
      // ignore
    }
  },
  reset: () => {
    pushHistory(get, set);
    set({ nodes: initialNodes, edges: [], selectedNodeId: null });
  },
}));

function pushHistory(
  get: () => WorkflowState,
  set: (partial: Partial<WorkflowState>) => void,
) {
  const { nodes, edges, past } = get();
  set({ past: [...past, { nodes, edges }].slice(-50), future: [] });
}