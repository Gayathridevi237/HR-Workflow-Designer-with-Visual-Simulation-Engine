export type NodeKind = "start" | "task" | "approval" | "automated" | "end";

export interface BaseNodeData {
  kind: NodeKind;
  title: string;
  [key: string]: unknown;
}

export interface StartNodeData extends BaseNodeData {
  kind: "start";
  metadata: string;
}

export interface TaskNodeData extends BaseNodeData {
  kind: "task";
  description: string;
  assignee: string;
  dueDate: string;
}

export interface ApprovalNodeData extends BaseNodeData {
  kind: "approval";
  approverRole: string;
  autoApproveThreshold: number;
}

export interface AutomatedNodeData extends BaseNodeData {
  kind: "automated";
  actionId: string;
  actionParams: Record<string, string>;
}

export interface EndNodeData extends BaseNodeData {
  kind: "end";
  message: string;
  showSummary: boolean;
}

export type WorkflowNodeData =
  | StartNodeData
  | TaskNodeData
  | ApprovalNodeData
  | AutomatedNodeData
  | EndNodeData;

export const NODE_LABELS: Record<NodeKind, string> = {
  start: "Start",
  task: "Task",
  approval: "Approval",
  automated: "Automated",
  end: "End",
};

export const NODE_COLORS: Record<NodeKind, string> = {
  start: "from-emerald-500/10 to-emerald-500/5 border-emerald-500/40 text-emerald-700 dark:text-emerald-300",
  task: "from-blue-500/10 to-blue-500/5 border-blue-500/40 text-blue-700 dark:text-blue-300",
  approval: "from-amber-500/10 to-amber-500/5 border-amber-500/40 text-amber-700 dark:text-amber-300",
  automated: "from-violet-500/10 to-violet-500/5 border-violet-500/40 text-violet-700 dark:text-violet-300",
  end: "from-rose-500/10 to-rose-500/5 border-rose-500/40 text-rose-700 dark:text-rose-300",
};

export const NODE_ACCENT: Record<NodeKind, string> = {
  start: "bg-emerald-500",
  task: "bg-blue-500",
  approval: "bg-amber-500",
  automated: "bg-violet-500",
  end: "bg-rose-500",
};

export function defaultDataFor(kind: NodeKind): WorkflowNodeData {
  switch (kind) {
    case "start":
      return { kind, title: "Start", metadata: "" };
    case "task":
      return {
        kind,
        title: "New Task",
        description: "",
        assignee: "",
        dueDate: "",
      };
    case "approval":
      return { kind, title: "Approval", approverRole: "Manager", autoApproveThreshold: 0 };
    case "automated":
      return { kind, title: "Automated Action", actionId: "", actionParams: {} };
    case "end":
      return { kind, title: "End", message: "Workflow complete", showSummary: true };
  }
}