import type { Edge, Node } from "@xyflow/react";
import type { WorkflowNodeData } from "./types";

export interface ValidationIssue {
  nodeId?: string;
  message: string;
  severity: "error" | "warning";
}

export function validateWorkflow(
  nodes: Node<WorkflowNodeData>[],
  edges: Edge[],
): ValidationIssue[] {
  const issues: ValidationIssue[] = [];

  const startNodes = nodes.filter((n) => n.data.kind === "start");
  if (startNodes.length === 0) {
    issues.push({ message: "Workflow must contain a Start node.", severity: "error" });
  } else if (startNodes.length > 1) {
    issues.push({ message: "Only one Start node is allowed.", severity: "error" });
  }

  const endNodes = nodes.filter((n) => n.data.kind === "end");
  if (endNodes.length === 0) {
    issues.push({ message: "Workflow should have at least one End node.", severity: "warning" });
  }

  // Per-node validation
  for (const n of nodes) {
    const d = n.data;
    const incoming = edges.filter((e) => e.target === n.id);
    const outgoing = edges.filter((e) => e.source === n.id);

    if (d.kind !== "start" && incoming.length === 0) {
      issues.push({ nodeId: n.id, message: `"${d.title}" has no incoming connection.`, severity: "warning" });
    }
    if (d.kind !== "end" && outgoing.length === 0) {
      issues.push({ nodeId: n.id, message: `"${d.title}" has no outgoing connection.`, severity: "warning" });
    }
    if (d.kind === "task" && !d.assignee.trim()) {
      issues.push({ nodeId: n.id, message: `Task "${d.title}" has no assignee.`, severity: "warning" });
    }
    if (d.kind === "automated" && !d.actionId) {
      issues.push({ nodeId: n.id, message: `Automated "${d.title}" has no action selected.`, severity: "error" });
    }
  }

  // Cycle detection (DFS)
  const adj = new Map<string, string[]>();
  edges.forEach((e) => {
    const list = adj.get(e.source) ?? [];
    list.push(e.target);
    adj.set(e.source, list);
  });
  const WHITE = 0, GRAY = 1, BLACK = 2;
  const color = new Map<string, number>();
  nodes.forEach((n) => color.set(n.id, WHITE));
  let hasCycle = false;
  function dfs(id: string) {
    color.set(id, GRAY);
    for (const next of adj.get(id) ?? []) {
      const c = color.get(next) ?? WHITE;
      if (c === GRAY) hasCycle = true;
      else if (c === WHITE) dfs(next);
    }
    color.set(id, BLACK);
  }
  for (const n of nodes) {
    if ((color.get(n.id) ?? WHITE) === WHITE) dfs(n.id);
    if (hasCycle) break;
  }
  if (hasCycle) {
    issues.push({ message: "Workflow contains a cycle.", severity: "error" });
  }

  return issues;
}