import { createFileRoute } from "@tanstack/react-router";
import { Workflow } from "lucide-react";
import { Canvas } from "@/features/workflow/components/Canvas";
import { Sidebar } from "@/features/workflow/components/Sidebar";
import { PropertiesPanel } from "@/features/workflow/components/PropertiesPanel";
import { SandboxPanel } from "@/features/workflow/components/SandboxPanel";
import { Toolbar } from "@/features/workflow/components/Toolbar";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  return (
    <div className="h-screen w-screen flex flex-col bg-background">
      <header className="border-b border-border bg-card/80 backdrop-blur-sm px-4 py-2.5 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-primary/70 text-primary-foreground shadow-md">
            <Workflow className="h-5 w-5" strokeWidth={2.5} />
          </div>
          <div>
            <h1 className="text-base font-semibold text-foreground leading-tight">
              HR Workflow Designer
            </h1>
            <p className="text-[11px] text-muted-foreground leading-tight">
              Design, validate, and simulate HR processes
            </p>
          </div>
        </div>
        <Toolbar />
      </header>
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <div className="flex flex-1 flex-col min-w-0">
          <Canvas />
          <SandboxPanel />
        </div>
        <PropertiesPanel />
      </div>
    </div>
  );
}
